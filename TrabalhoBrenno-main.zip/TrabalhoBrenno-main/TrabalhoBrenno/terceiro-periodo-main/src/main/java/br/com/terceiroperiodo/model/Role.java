package br.com.terceiroperiodo.model;

public enum Role {

    ADMIN,
    USER,
    MANAGER

}
